# Property Assistant Backend

Modular backend for the Buyer's Advantage tool.